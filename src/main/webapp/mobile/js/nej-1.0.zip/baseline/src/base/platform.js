/*
 * ------------------------------------------
 * 平台接口实现文件
 * @version  1.0
 * @author   genify(caijf@corp.netease.com)
 * ------------------------------------------
 */
var f = function(){
    // variable declaration
    var _  = NEJ.P,
        _o = NEJ.O,
        _p = _('nej.p'),
        _platform  = window.navigator.platform,
        _useragent = window.navigator.userAgent;
    /**
     * 平台判断信息
     * 
     * [ntb]
     *  参数名称       | 参数类型          | 参数描述
     *  ------------------------------------
     *  mac      | Boolean    | is mac os
     *  win      | Boolean    | is windows os
     *  linux    | Boolean    | is linux os
     *  ipad     | Boolean    | is ipad device
     *  iphone   | Boolean    | is iphone device
     *  android  | Boolean    | is android system
     *  ios      | Boolean    | is ios system
     *  tablet   | Boolean    | is tablet
     *  desktop  | Boolean    | is desktop env
     * [/ntb]
     * 
     * @const  {nej.p._$IS}
     * @type   {Object}
     */
    var _is = {
        mac        : _platform
       ,win        : _platform
       ,linux      : _platform
       ,ipad       : _useragent
       ,ipod       : _useragent
       ,iphone     : _platform
       ,android    : _useragent
    };
    _p._$IS = _is;
    for(var x in _is)
        _is[x] = new RegExp(x,'i').test(_is[x]);
    _is.ios = _is.ipad||_is.iphone||_is.ipod;
    _is.tablet = _is.ipad;
    _is.desktop = _is.mac||_is.win||(_is.linux&&!_is.android);
    // parse kernel information
    /**
     * 引擎内核信息
     * 
     * [ntb]
     *  参数名称       | 参数类型          | 参数描述
     *  ------------------------------------
     *  engine   | String  | layout engine, trident/webkit/gecko/presto...
     *  release  | Number  | layout engine version
     *  browser  | String  | browser name, ie/chrome/safari/opera/firefox/maxthon...
     *  version  | Number  | browser version
     *  prefix   | Object  | prefix for html5/css3 attribute/method/constructor name
     * [/ntb]
     * 
     * @const  {nej.p._$KERNEL}
     * @type   {Object}
     */
    var _kernel = {
        engine:'unknow',
        release:'unknow',
        browser:'unknow',
        version:'unknow',
        prefix:{css:'',pro:'',clz:''}
    };
    _p._$KERNEL  = _kernel;
    if (/msie\s+(.*?);/i.test(_useragent)){
        _kernel.engine  = 'trident';
        _kernel.browser = 'ie';
        _kernel.version = RegExp.$1;
        _kernel.prefix  = {css:'ms',pro:'ms',clz:'MS',evt:'MS'};
        // 4.0-ie8 5.0-ie9 6.0-ie10
        // adjust by document mode setting in develop toolbar
        var _test = {6:'2.0',7:'3.0',8:'4.0',9:'5.0',10:'6.0'};
        _kernel.release = _test[document.documentMode]||
                          _test[parseInt(_kernel.version)];
    }else if(/webkit\/?([\d.]+?)(?=\s|$)/i.test(_useragent)){
        _kernel.engine  = 'webkit';
        _kernel.release = RegExp.$1||'';
        _kernel.prefix  = {css:'webkit',pro:'webkit',clz:'WebKit'};
    }else if(/rv\:(.*?)\)\s+gecko\//i.test(_useragent)){
        _kernel.engine  = 'gecko';
        _kernel.release = RegExp.$1||'';
        _kernel.browser = 'firefox';
        _kernel.prefix  = {css:'Moz',pro:'moz',clz:'Moz'};
        if (/firefox\/(.*?)(?=\s|$)/i.test(_useragent))
            _kernel.version = RegExp.$1||'';
    }else if(/presto\/(.*?)\s/i.test(_useragent)){
        _kernel.engine  = 'presto';
        _kernel.release = RegExp.$1||'';
        _kernel.browser = 'opera';
        _kernel.prefix  = {css:'O',pro:'o',clz:'O'};
        if (/version\/(.*?)(?=\s|$)/i.test(_useragent))
            _kernel.version = RegExp.$1||'';
    }
    if (_kernel.browser=='unknow'){
        var _test = ['chrome','maxthon','safari'];
        for(var i=0,l=_test.length,_name;i<l;i++){
            _name = _test[i]=='safari'?'version':_test[i];
            if (new RegExp(_name+'/(.*?)(?=\\s|$)','i').test(_useragent)){
                _kernel.browser = _test[i];
                _kernel.version = RegExp.$1.trim();
                break;
            }
        }
    }
    /**
     * 引擎属性支持信息<br/>
     * css3d - can support css 3d effect
     * @const  {nej.p._$SUPPORT}
     * @type   {Object}
     */
    _p._$SUPPORT = {};
    /**
     * 平台补丁判断信息
     * [ntb]
     *  参数名称       | 参数类型          | 参数描述
     *  ------------------------------------
     *  gecko    | Boolean  | not gecko
     *  webkit   | Boolean  | not webkit
     *  presto   | Boolean  | not presto
     *  trident  | Boolean  | not trident
     *  trident1 | Boolean  | not trident1
     *  trident2 | Boolean  | not trident2
     * [/ntb]
     * @const  {nej.p._$NOT_PATCH}
     * @type   {Object}
     */
    _p._$NOT_PATCH = {
        gecko : _kernel.engine!='gecko'
       ,webkit: _kernel.engine!='webkit'
       ,presto: _kernel.engine!='presto'
       // split trident with ie10(html5/css3 support)
       ,trident  : _kernel.engine!='trident'||_kernel.release>='6.0'
       ,trident1 : _kernel.engine!='trident'||_kernel.release<'6.0'
       // fix for ie6
       ,trident2 : _kernel.engine!='trident'||_kernel.release!='2.0'
    };
};
define('{lib}base/platform.js',
      ['{lib}base/global.js'],f);