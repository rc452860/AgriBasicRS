var f = function(){
    
};
define('{lib}patched/gecko/message.js',
      ['{lib}patched/message.js'],f);