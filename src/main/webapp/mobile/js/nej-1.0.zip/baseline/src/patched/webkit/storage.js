var f = function(){
    
};
define('{lib}patched/webkit/storage.js',
      ['{lib}patched/storage.js'],f);