var f = function(){
    
};
define('{lib}patched/gecko/holder.js',
      ['{lib}patched/holder.js'],f);