var f = function(){
    
};
define('{lib}patched/gecko/config.js',
      ['{lib}patched/config.js'],f);