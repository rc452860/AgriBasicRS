var f = function(){
    
};
define('{lib}patched/trident-1/holder.js',
      ['{lib}patched/holder.js'],f);