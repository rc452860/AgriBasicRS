var f = function(){
    
};
define('{lib}patched/presto/storage.js',
      ['{lib}patched/storage.js'],f);