var f = function(){
    
};
define('{lib}patched/presto/ajax.js',
      ['{lib}patched/ajax.js'],f);