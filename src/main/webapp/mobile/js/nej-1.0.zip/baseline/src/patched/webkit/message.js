var f = function(){
    
};
define('{lib}patched/webkit/message.js',
      ['{lib}patched/message.js'],f);