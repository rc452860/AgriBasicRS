var f = function(){
    
};
define('{lib}patched/presto/message.js',
      ['{lib}patched/message.js'],f);