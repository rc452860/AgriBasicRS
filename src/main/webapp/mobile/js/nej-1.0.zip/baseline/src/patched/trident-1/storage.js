var f = function(){
    
};
define('{lib}patched/trident-1/storage.js',
      ['{lib}patched/storage.js'],f);