var f = function(){
    
};
define('{lib}patched/trident-1/message.js',
      ['{lib}patched/message.js'],f);