var f = function(){
    
};
define('{lib}patched/presto/config.js',
      ['{lib}patched/config.js'],f);