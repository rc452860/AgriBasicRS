var f = function(){
    
};
define('{lib}patched/gecko/ajax.js',
      ['{lib}patched/ajax.js'],f);