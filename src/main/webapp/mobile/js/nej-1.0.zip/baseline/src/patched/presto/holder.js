var f = function(){
    
};
define('{lib}patched/presto/holder.js',
      ['{lib}patched/holder.js'],f);