var f = function(){
    
};
define('{lib}patched/trident-1/config.js',
      ['{lib}patched/config.js'],f);