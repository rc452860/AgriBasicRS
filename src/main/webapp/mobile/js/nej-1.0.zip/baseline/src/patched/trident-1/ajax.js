var f = function(){
    
};
define('{lib}patched/trident-1/ajax.js',
      ['{lib}patched/ajax.js'],f);