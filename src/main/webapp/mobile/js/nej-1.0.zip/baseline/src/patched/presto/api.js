var f = function(){
    
};
define('{lib}patched/presto/api.js',
      ['{lib}patched/api.js'],f);