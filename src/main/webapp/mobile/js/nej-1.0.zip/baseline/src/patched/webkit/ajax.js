var f = function(){
    
};
define('{lib}patched/webkit/ajax.js',
      ['{lib}patched/ajax.js'],f);