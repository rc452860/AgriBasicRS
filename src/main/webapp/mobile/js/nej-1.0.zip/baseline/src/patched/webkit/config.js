var f = function(){
    
};
define('{lib}patched/webkit/config.js',
      ['{lib}patched/config.js'],f);