var f = function(){
    
};
define('{lib}patched/gecko/storage.js',
      ['{lib}patched/storage.js'],f);