var f = function(){
    
};
define('{lib}patched/webkit/holder.js',
      ['{lib}patched/holder.js'],f);